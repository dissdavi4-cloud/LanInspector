# LAN Inspector

App Android para examinar a rede local à qual o próprio celular está conectado.

## Recursos
- **Este aparelho**: fabricante, modelo, marca e versão do Android do próprio celular.
- **Conexão Wi-Fi / roteador**: SSID, BSSID do roteador, IP local, gateway, máscara, DNS, velocidade do link e sinal (RSSI).
- **Varredura da rede local**: procura hosts que respondam na sub-rede, com uma segunda passada lendo a tabela ARP do sistema (`/proc/net/arp`) para tentar obter o endereço MAC de cada um.
- **Identificação aproximada de fabricante e tipo**: usa os 3 primeiros bytes do MAC (prefixo OUI) contra uma tabela de fabricantes comuns (Apple, Samsung, Xiaomi, Dell, HP, Intel, Microsoft, Raspberry Pi, etc.), combinado com o nome de rede anunciado pelo aparelho e portas comuns abertas, para estimar se é um celular, um PC Windows, um computador Linux/servidor, uma TV/streaming ou outro tipo de dispositivo.
- Não captura tráfego, não lê senhas nem conteúdo de outros aparelhos.

### Sobre as limitações de identificação
Não existe uma forma confiável de obter o **modelo exato** de outro aparelho apenas observando a rede — isso exigiria que o próprio aparelho divulgasse essa informação, o que a maioria não faz. O app mostra o melhor palpite possível (fabricante pelo MAC + nome de rede + portas abertas), igual a apps como o Fing. Além disso, a partir do Android 10 o sistema restringe a leitura de `/proc/net/arp` em muitos aparelhos: quando isso acontece, o MAC e o fabricante aparecem como indisponíveis, mas o restante da varredura continua funcionando.

## Sobre desautenticar, "derrubar" ou expulsar aparelhos da rede
**Esse recurso não foi incluído, de propósito.** Forçar a desconexão de outro aparelho de uma rede Wi-Fi (deauth 802.11) é, na prática, uma técnica de ataque de negação de serviço: ela depende de enviar quadros de controle Wi-Fi falsificados, normalmente precisa de hardware/driver em modo monitor com injeção de pacotes (o que a grande maioria dos celulares Android não suporta sem root e firmware alterado), e o mesmo código serve tanto para "tirar alguém do próprio Wi-Fi" quanto para atacar a rede de terceiros — é exatamente esse o motivo de apps desse tipo (ex.: NetCut, WiFiKill) serem banidos de lojas de aplicativos. Por isso eu não vou implementar esse recurso, nem aqui nem em outra versão.

**O caminho legítimo e que realmente funciona** é usar o próprio painel de administração do seu roteador:
1. Descubra o IP do roteador no card "Conexão Wi-Fi / roteador" deste app (campo "IP do roteador").
2. Abra esse IP no navegador do celular ou do computador conectado à mesma rede.
3. Entre com o usuário/senha do roteador (geralmente estão numa etiqueta no próprio aparelho, se nunca foram trocados).
4. Procure por "Dispositivos conectados", "Controle de acesso", "Controle dos pais" ou "Lista de bloqueio" — praticamente todo roteador doméstico moderno tem uma dessas seções, onde dá para bloquear ou pausar o acesso de um aparelho específico pelo MAC, de forma persistente e sem precisar ficar enviando nada toda hora.

## Build (GitHub Actions)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta para a branch `main` (os arquivos `build.gradle`, `settings.gradle`, `gradle.properties`, a pasta `app/` e a pasta `.github/`).
2. Vá na aba **Actions** do repositório e rode o workflow **Build Android APK** (ou simplesmente dê um push na `main`, que ele roda sozinho).
3. Quando terminar, baixe o artefato **LANInspector-debug-apk** gerado na execução — é o `.apk` para instalar no celular (ative "instalar de fontes desconhecidas" para instalar manualmente).

Requisitos usados pelo workflow: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compileSdk 35.
