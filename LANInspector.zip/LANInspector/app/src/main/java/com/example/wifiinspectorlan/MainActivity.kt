package com.example.wifiinspectorlan

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/**
 * LAN Inspector
 *
 * Mostra dados da própria conexão Wi-Fi e varre a sub-rede local em busca de
 * aparelhos que respondam, tentando identificar tipo/fabricante de forma
 * aproximada a partir do nome anunciado, do endereço MAC (tabela ARP) e de
 * portas de rede comuns. Não captura tráfego, não lê conteúdo de outros
 * aparelhos e não derruba ou desconecta ninguém da rede — veja o README para
 * o motivo.
 */

data class DeviceInfo(
    val ip: String,
    val hostname: String,
    val mac: String?,
    val vendor: String?,
    val guess: String,
    val ports: String,
    val isGateway: Boolean
)

class MainActivity : Activity() {

    private lateinit var deviceCardBody: TextView
    private lateinit var connectionCardBody: TextView
    private lateinit var status: TextView
    private lateinit var resultsContainer: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    private val locationPermissionCode = 101

    // Prefixos OUI (3 primeiros bytes do MAC, sem separador, maiúsculo) -> fabricante.
    // Lista enxuta com fabricantes comuns de celulares, PCs e dispositivos domésticos.
    private val ouiVendors = mapOf(
        "F4F5D8" to "Google", "3C5AB4" to "Google", "DA A1 19".replace(" ", "") to "Google",
        "A4C361" to "Apple", "F0B479" to "Apple", "3C0754" to "Apple", "F4F15A" to "Apple", "AC87A3" to "Apple",
        "E88E40" to "Samsung", "5C0A5B" to "Samsung", "8471C5" to "Samsung", "001377" to "Samsung", "C0BDD1" to "Samsung",
        "286C07" to "Xiaomi", "F8A45F" to "Xiaomi", "64B473" to "Xiaomi", "9C99A0" to "Xiaomi",
        "A4772B" to "Huawei", "00E0FC" to "Huawei", "28A6DB" to "Huawei",
        "FCFC48" to "Motorola", "D42C44" to "Motorola",
        "D83062" to "OnePlus", "A0F3C1" to "OnePlus",
        "D0817A" to "Sony", "0024BE" to "Sony",
        "001E75" to "LG Electronics", "88C9D0" to "LG Electronics",
        "00155D" to "Microsoft", "0003FF" to "Microsoft", "7085C2" to "Microsoft",
        "001C23" to "Dell", "B88303" to "Dell", "14FEB5" to "Dell",
        "3C4A92" to "HP", "9C8E99" to "HP", "A0D3C1" to "HP",
        "0014F1" to "Lenovo", "A44CC8" to "Lenovo",
        "001320" to "Intel", "8C705A" to "Intel", "A434D9" to "Intel",
        "B827EB" to "Raspberry Pi", "DCA632" to "Raspberry Pi", "E45F01" to "Raspberry Pi",
        "F0272D" to "Amazon", "ACF85C" to "Amazon",
        "001FC6" to "Nintendo", "B8AE6E" to "Nintendo",
        "000D93" to "TP-Link", "E894F6" to "TP-Link",
        "0024A5" to "Netgear", "A0040D" to "Netgear",
        "001195" to "D-Link", "CCB255" to "D-Link",
        "5CCF7F" to "Espressif (IoT/ESP)", "A020A6" to "Espressif (IoT/ESP)", "84F3EB" to "Espressif (IoT/ESP)",
        "000C29" to "VMware (máquina virtual)", "005056" to "VMware (máquina virtual)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), locationPermissionCode
            )
        }
        showDeviceInfo()
        showConnectionInfo()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) showConnectionInfo()
    }

    // ---------- UI ----------

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F5F7FA"))
            setPadding(dp(16), dp(20), dp(16), dp(12))
        }

        val title = TextView(this).apply {
            text = "LAN Inspector"
            textSize = 26f
            setTextColor(Color.parseColor("#1C1E21"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Visão geral da sua rede local. Identificação de fabricante e tipo de aparelho é aproximada."
            textSize = 13f
            setTextColor(Color.parseColor("#5F6B7A"))
            setPadding(0, dp(4), 0, dp(14))
        }

        val deviceCard = makeCard()
        val deviceCardTitle = cardTitle("Este aparelho")
        deviceCardBody = cardBody("Carregando…")
        deviceCard.addView(wrapCard(deviceCardTitle, deviceCardBody))

        val connectionCard = makeCard()
        val connectionCardTitle = cardTitle("Conexão Wi-Fi / roteador")
        connectionCardBody = cardBody("Carregando…")
        connectionCard.addView(wrapCard(connectionCardTitle, connectionCardBody))

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(4))
        }
        val refreshBtn = MaterialButton(this).apply {
            text = "Atualizar conexão"
            setOnClickListener { showConnectionInfo() }
        }
        val scanBtn = MaterialButton(this).apply {
            text = "Procurar aparelhos"
            setOnClickListener { scanLan() }
        }
        val rowParamsA = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) }
        val rowParamsB = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        buttonRow.addView(refreshBtn, rowParamsA)
        buttonRow.addView(scanBtn, rowParamsB)

        status = TextView(this).apply {
            text = "Pronto. Toque em \"Procurar aparelhos\" para varrer a rede local."
            textSize = 13f
            setTextColor(Color.parseColor("#5F6B7A"))
            setPadding(0, dp(10), 0, dp(6))
        }

        val resultsHeader = TextView(this).apply {
            text = "Aparelhos encontrados"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.parseColor("#1C1E21"))
            setPadding(0, dp(8), 0, dp(6))
        }

        resultsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(resultsContainer) }

        root.addView(title)
        root.addView(subtitle)
        root.addView(deviceCard, cardParams())
        root.addView(connectionCard, cardParams())
        root.addView(buttonRow)
        root.addView(status)
        root.addView(resultsHeader)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun cardParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(10) }

    private fun makeCard(): CardView = CardView(this).apply {
        radius = dp(14).toFloat()
        cardElevation = dp(2).toFloat()
        setCardBackgroundColor(Color.WHITE)
        useCompatPadding = true
    }

    private fun cardTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(Color.parseColor("#1565C0"))
    }

    private fun cardBody(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13.5f
        setTextColor(Color.parseColor("#1C1E21"))
        setTextIsSelectable(true)
        setPadding(0, dp(6), 0, 0)
    }

    private fun wrapCard(titleView: TextView, bodyView: TextView): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(titleView)
            addView(bodyView)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // ---------- Dados do próprio aparelho ----------

    private fun showDeviceInfo() {
        deviceCardBody.text = buildString {
            appendLine("Fabricante: ${Build.MANUFACTURER}")
            appendLine("Modelo: ${Build.MODEL}")
            appendLine("Marca: ${Build.BRAND}")
            append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        }
    }

    // ---------- Conexão / roteador ----------

    private fun showConnectionInfo() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val lp = cm.getLinkProperties(cm.activeNetwork)
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val dhcp = wifi.dhcpInfo
            val ip = Formatter.formatIpAddress(dhcp.ipAddress)
            val gateway = Formatter.formatIpAddress(dhcp.gateway)
            val mask = Formatter.formatIpAddress(dhcp.netmask)
            val dns1 = Formatter.formatIpAddress(dhcp.dns1)
            val dns2 = Formatter.formatIpAddress(dhcp.dns2)

            val hasLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
            @Suppress("DEPRECATION")
            val info = wifi.connectionInfo
            val ssid = if (hasLocation) {
                val raw = info?.ssid ?: "indisponível"
                if (raw == "<unknown ssid>") "indisponível (ative o GPS/localização)" else raw.removeSurrounding("\"")
            } else "conceda a permissão de localização para ver o nome da rede"
            @Suppress("DEPRECATION")
            val bssid = if (hasLocation) (info?.bssid ?: "indisponível") else "oculto sem permissão"
            @Suppress("DEPRECATION")
            val linkSpeed = info?.linkSpeed ?: -1
            @Suppress("DEPRECATION")
            val rssi = info?.rssi ?: 0

            val arp = readArpTable()
            val gatewayMac = arp[gateway]
            val gatewayVendor = gatewayMac?.let { vendorFromMac(it) }

            connectionCardBody.text = buildString {
                appendLine("Rede (SSID): $ssid")
                appendLine("Roteador (BSSID): $bssid")
                if (gatewayVendor != null) appendLine("Fabricante do roteador (aprox.): $gatewayVendor")
                appendLine("IP deste celular: $ip")
                appendLine("IP do roteador (gateway): $gateway")
                appendLine("Máscara de sub-rede: $mask")
                appendLine("DNS 1: $dns1")
                appendLine("DNS 2: $dns2")
                appendLine("Interface: ${lp?.interfaceName ?: "indisponível"}")
                if (linkSpeed > 0) appendLine("Velocidade do link: ${linkSpeed} Mbps")
                if (rssi != 0) append("Sinal (RSSI): $rssi dBm")
            }
        } catch (e: Exception) {
            connectionCardBody.text = "Não foi possível ler os dados da conexão: ${e.message}"
        }
    }

    // ---------- Varredura da rede local ----------

    private fun scanLan() {
        status.text = "Buscando aparelhos na sub-rede local…"
        resultsContainer.removeAllViews()
        executor.execute {
            val found = mutableListOf<DeviceInfo>()
            try {
                val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val dhcp = wifi.dhcpInfo
                val local = dhcp.ipAddress
                val mask = dhcp.netmask
                val gatewayIp = Formatter.formatIpAddress(dhcp.gateway)
                if (local == 0 || mask == 0) throw IllegalStateException("Conecte o celular ao Wi-Fi.")
                val network = local and mask
                val broadcast = network or mask.inv()
                val start = network + 1
                val end = minOf(broadcast - 1, start + 253)

                for (host in start..end) {
                    if (host == local) continue
                    val ip = intToIp(host)
                    try {
                        val addr: InetAddress = InetAddress.getByName(ip)
                        val reachable = addr.isReachable(220)
                        val open = mutableListOf<Int>()
                        for (port in intArrayOf(22, 80, 139, 443, 445, 554, 3389, 8008, 8009, 8080, 8443, 9100)) {
                            try {
                                Socket().use { s ->
                                    s.connect(InetSocketAddress(ip, port), 120)
                                    open.add(port)
                                }
                            } catch (_: Exception) {}
                        }
                        if (reachable || open.isNotEmpty()) {
                            val hostName = try {
                                val name = addr.canonicalHostName
                                if (name == ip) null else name
                            } catch (_: Exception) { null }
                            found.add(DeviceInfo(ip, hostName ?: "nome não anunciado", null, null, "", openPortsText(open), ip == gatewayIp))
                        }
                    } catch (_: Exception) {}
                }

                // Segunda passada: agora que houve tráfego com cada host, a tabela ARP
                // deve conter os MACs correspondentes.
                val arp = readArpTable()
                val withMac = found.map { d ->
                    val mac = arp[d.ip]
                    val vendor = mac?.let { vendorFromMac(it) }
                    val guess = classify(d.hostname, mac, vendor, portsFromText(d.ports), d.isGateway)
                    d.copy(mac = mac, vendor = vendor, guess = guess)
                }
                found.clear()
                found.addAll(withMac)
            } catch (e: Exception) {
                runOnUiThread { status.text = "Falha na busca: ${e.message ?: "erro desconhecido"}" }
                return@execute
            }
            runOnUiThread {
                status.text = "Busca concluída: ${found.size} aparelho(s) responderam."
                if (found.isEmpty()) {
                    val empty = cardBody(
                        "Nenhum dispositivo respondeu. Isso não significa que não existam aparelhos conectados: " +
                            "roteadores, celulares e PCs modernos costumam bloquear esse tipo de descoberta por padrão."
                    )
                    resultsContainer.addView(empty)
                } else {
                    found.sortedBy { ipSortKey(it.ip) }.forEach { addDeviceCard(it) }
                }
            }
        }
    }

    private fun addDeviceCard(d: DeviceInfo) {
        val card = makeCard()
        val titleText = if (d.isGateway) "${d.ip} — Roteador" else d.ip
        val title = cardTitle(titleText)
        val body = cardBody(buildString {
            appendLine("Nome anunciado: ${d.hostname}")
            if (d.mac != null) appendLine("MAC: ${d.mac}") else appendLine("MAC: não disponível (restrição do Android ou aparelho ainda sem tráfego registrado)")
            if (d.vendor != null) appendLine("Fabricante (aprox.): ${d.vendor}")
            appendLine("Tipo provável: ${d.guess}")
            append("Portas detectadas: ${d.ports}")
        })
        card.addView(wrapCard(title, body))
        resultsContainer.addView(card, cardParams())
    }

    private fun openPortsText(open: List<Int>) = if (open.isEmpty()) "nenhuma porta comum detectada" else open.joinToString()

    private fun portsFromText(text: String): List<Int> =
        text.split(",").mapNotNull { it.trim().toIntOrNull() }

    private fun classify(hostRaw: String, mac: String?, vendor: String?, ports: List<Int>, isGateway: Boolean): String {
        if (isGateway) return "Roteador (gateway da rede)"
        val h = hostRaw.lowercase()
        val v = vendor?.lowercase() ?: ""

        val looksWindows = 445 in ports || 3389 in ports || 139 in ports ||
            h.startsWith("desktop-") || h.startsWith("win-") ||
            listOf("dell", "hp", "lenovo", "microsoft", "intel").any { v.contains(it) }
        val looksLinuxLike = 22 in ports && !looksWindows
        val looksTv = listOf("tv", "roku", "chromecast", "fire", "bravia", "webostv").any { h.contains(it) } ||
            554 in ports || 8008 in ports || 8009 in ports
        val looksPhone = listOf("apple", "samsung", "xiaomi", "huawei", "motorola", "oneplus", "sony", "lg electronics")
            .any { v.contains(it) } && !looksWindows && !looksTv
        val looksVm = v.contains("vmware")
        val looksIot = v.contains("espressif")

        return when {
            looksTv -> "TV / streaming (provável)" + if (vendor != null) " — $vendor" else ""
            looksWindows -> "PC Windows (provável)" + if (vendor != null) " — $vendor" else ""
            looksLinuxLike -> "Computador Linux / servidor (provável, porta SSH aberta)"
            looksPhone -> "Celular/tablet (provável) — $vendor"
            looksVm -> "Máquina virtual (provável)"
            looksIot -> "Dispositivo IoT (provável) — $vendor"
            vendor != null -> "Dispositivo de rede — fabricante aprox.: $vendor"
            else -> "Dispositivo de rede (tipo não confirmado)"
        }
    }

    // ---------- Tabela ARP (IP -> MAC) ----------

    private fun readArpTable(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        try {
            val file = File("/proc/net/arp")
            if (!file.exists() || !file.canRead()) return result
            BufferedReader(FileReader(file)).use { reader: BufferedReader ->
                reader.readLine() // cabeçalho
                reader.forEachLine { line ->
                    val cols = line.trim().split(Regex("\\s+"))
                    // IP address  HW type  Flags  HW address  Mask  Device
                    if (cols.size >= 4) {
                        val ip = cols[0]
                        val mac = cols[3]
                        if (mac != "00:00:00:00:00:00") result[ip] = mac.uppercase()
                    }
                }
            }
        } catch (_: Exception) {
            // Em muitas versões recentes do Android, apps comuns não conseguem ler
            // /proc/net/arp. Nesse caso simplesmente não mostramos o MAC.
        }
        return result
    }

    private fun vendorFromMac(mac: String): String? {
        val oui = mac.replace(":", "").replace("-", "").uppercase().take(6)
        if (oui.length < 6) return null
        return ouiVendors[oui]
    }

    private fun intToIp(value: Int): String =
        "${value and 0xff}.${(value shr 8) and 0xff}.${(value shr 16) and 0xff}.${(value shr 24) and 0xff}"

    private fun ipSortKey(ip: String): Int =
        ip.split(".").mapNotNull { it.toIntOrNull() }
            .fold(0) { acc, part -> (acc shl 8) or part }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
