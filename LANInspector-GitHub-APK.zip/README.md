# LAN Inspector

App Android educativo para examinar a rede local à qual o próprio celular está conectado.

## Recursos
- IP local do celular, gateway/roteador, máscara e DNS.
- Varredura limitada à sub-rede local para encontrar hosts que respondam.
- Tentativa de identificação aproximada de TVs/streaming e computadores por nome e portas comuns.
- Não captura tráfego, não lê senhas, não explora serviços e não desconecta aparelhos.

## Sobre pausar ou remover dispositivos
O Android não oferece uma API comum para expulsar clientes do roteador. Para pausar um aparelho, use o aplicativo ou painel oficial do seu roteador, na seção de dispositivos conectados / controle dos pais / controle de acesso. A disponibilidade depende do modelo do roteador. Este app não implementa desautenticação 802.11.

## Build
Envie os arquivos para um repositório GitHub e abra Actions. Execute `Build Android APK`. Baixe o artefato `LANInspector-debug-apk` na execução concluída.

Requisitos: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3 e compileSdk 35.
