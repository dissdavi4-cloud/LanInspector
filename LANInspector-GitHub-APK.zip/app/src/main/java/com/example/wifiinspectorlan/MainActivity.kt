package com.example.wifiinspectorlan

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.InetAddress
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

data class DeviceInfo(val ip: String, val hostname: String, val guess: String, val ports: String)

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 18)
        }
        val title = TextView(this).apply {
            text = "LAN Inspector"
            textSize = 25f
            setGravity(Gravity.CENTER_VERTICAL)
        }
        val description = TextView(this).apply {
            text = "Análise da sua rede local. A identificação de TVs e computadores é aproximada; alguns aparelhos não respondem à descoberta."
            textSize = 14f
            setPadding(0, 10, 0, 14)
        }
        val router = Button(this).apply {
            text = "Ver dados da minha conexão"
            setOnClickListener { showConnectionInfo() }
        }
        val scan = Button(this).apply {
            text = "Procurar aparelhos na minha rede"
            setOnClickListener { scanLan() }
        }
        status = TextView(this).apply {
            text = "Pronto. Conecte-se ao seu Wi-Fi e inicie a busca."
            textSize = 14f
            setPadding(0, 14, 0, 8)
        }
        output = TextView(this).apply {
            textSize = 15f
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title)
        root.addView(description)
        root.addView(router)
        root.addView(scan)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showConnectionInfo() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val lp: LinkProperties? = cm.getLinkProperties(cm.activeNetwork)
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val dhcp = wifi.dhcpInfo
            val ip = Formatter.formatIpAddress(dhcp.ipAddress)
            val gateway = Formatter.formatIpAddress(dhcp.gateway)
            val mask = Formatter.formatIpAddress(dhcp.netmask)
            val dns1 = Formatter.formatIpAddress(dhcp.dns1)
            val dns2 = Formatter.formatIpAddress(dhcp.dns2)
            val details = buildString {
                appendLine("INFORMAÇÕES DA CONEXÃO")
                appendLine("IP do celular: $ip")
                appendLine("Gateway/roteador: $gateway")
                appendLine("Máscara: $mask")
                appendLine("DNS 1: $dns1")
                appendLine("DNS 2: $dns2")
                appendLine("Interface: ${lp?.interfaceName ?: "indisponível"}")
                appendLine()
                append("O endereço do gateway normalmente é o IP do painel do roteador.")
            }
            output.text = details
            status.text = "Dados locais da conexão carregados."
        } catch (e: Exception) {
            output.text = "Não foi possível ler os dados da conexão: ${e.message}"
        }
    }

    private fun scanLan() {
        status.text = "Buscando dispositivos na sub-rede local…"
        output.text = "Aguarde. A busca pode levar alguns segundos.\\n"
        executor.execute {
            val found = mutableListOf<DeviceInfo>()
            try {
                val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val dhcp = wifi.dhcpInfo
                val local = dhcp.ipAddress
                val mask = dhcp.netmask
                if (local == 0 || mask == 0) throw IllegalStateException("Conecte o celular ao Wi-Fi.")
                val network = local and mask
                val broadcast = network or mask.inv()
                val start = network + 1
                val end = minOf(broadcast - 1, start + 253)
                for (host in start..end) {
                    if (host == local) continue
                    val ip = intToIp(host)
                    try {
                        val addr = InetAddress.getByName(ip)
                        // Reachability check plus a small set of common service ports.
                        val reachable = addr.isReachable(220)
                        val open = mutableListOf<Int>()
                        for (port in intArrayOf(80, 443, 554, 8008, 8009, 8080, 8443)) {
                            try {
                                Socket().use { s ->
                                    s.connect(InetSocketAddress(ip, port), 120)
                                    open.add(port)
                                }
                            } catch (_: Exception) {}
                        }
                        if (reachable || open.isNotEmpty()) {
                            val hostName = try {
                                val name = addr.canonicalHostName
                                if (name == ip) "nome não anunciado" else name
                            } catch (_: Exception) { "nome não anunciado" }
                            val guess = classify(hostName, open)
                            found.add(DeviceInfo(ip, hostName, guess, if (open.isEmpty()) "nenhuma porta comum detectada" else open.joinToString()))
                        }
                    } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Falha na busca: ${e.message ?: "erro desconhecido"}"
                }
                return@execute
            }
            runOnUiThread {
                status.text = "Busca concluída: ${found.size} aparelho(s) responderam."
                output.text = if (found.isEmpty()) {
                    "Nenhum dispositivo respondeu. Isso não significa que não existam aparelhos conectados: roteadores e celulares podem bloquear descobertas."
                } else {
                    found.sortedBy { it.ip }.joinToString("\\n\\n") { d ->
                        "IP: ${d.ip}\\nNome: ${d.hostname}\\nPossível tipo: ${d.guess}\\nPortas comuns detectadas: ${d.ports}"
                    } + "\\n\\nObservação: TVs, PCs e celulares podem aparecer como desconhecidos. A varredura não lê tráfego privado, senhas ou conteúdo dos aparelhos."
                }
            }
        }
    }

    private fun classify(host: String, ports: List<Int>): String {
        val h = host.lowercase()
        return when {
            listOf("tv", "roku", "chromecast", "fire", "samsung", "lgwebostv", "bravia").any { h.contains(it) } || 554 in ports || 8008 in ports || 8009 in ports -> "TV / streaming (possível)"
            listOf("desktop", "pc", "laptop", "notebook", "windows", "macbook").any { h.contains(it) } || 445 in ports || 3389 in ports -> "Computador (possível)"
            else -> "Dispositivo de rede (tipo não confirmado)"
        }
    }

    private fun intToIp(value: Int): String =
        "${value and 0xff}.${(value shr 8) and 0xff}.${(value shr 16) and 0xff}.${(value shr 24) and 0xff}"

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
